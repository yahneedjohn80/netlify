// A $( document ).ready() block.
$( document ).ready(function() {
    //alert("My Alert");
  
  // Carousel Interval
  $('.carousel').carousel({
  interval: 2000
})

});

AOS.init();
 